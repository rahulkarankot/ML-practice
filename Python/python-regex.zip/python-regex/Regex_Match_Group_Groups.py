#!/usr/bin/python3
import re

line = "Python and Perl are programming and scripting languages"

#matchObj = re.match(r'(.*) are (.*?) .*', line, re.M|re.I)
#matchObj = re.match(r'(.*) are (.*?)', line, re.M|re.I)
#matchObj = re.match(r'(.*) are (.*) .*', line, re.M|re.I)
matchObj = re.match(r'(.*) are (.*)', line, re.M|re.I)

if matchObj:
   print ("matchObj.group() : ", matchObj.group())
   print ("matchObj.group(1) : ", matchObj.group(1))
   print ("matchObj.groups() : ", matchObj.groups())
else:
   print ("No match!!")

'''
# Syntax : re.match(pattern, string, flags=0)

pattern	: This is the regular expression to be matched.
string	: This is the string, which would be searched to match
          the pattern at the beginning of string.
flags	: You can specify different flags using bitwise OR (|).

MULTILINE, M	  Multi-line matching, affecting ^ and $
IGNORECASE, I	  Do case-insensitive matches
Raw Strings as r'expression'

group(num=0)	This method returns entire match (or specific subgroup num)
groups()	This method returns all matching subgroups in a tuple
               (empty if there were not any)

'''
