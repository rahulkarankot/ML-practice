#!/usr/bin/python3

import re

line = "Python and Perl are programming languages redhat"

#matchObj = re.match( r'(.*) and (.*) (.*?) .*', line, re.M|re.I)

matchObj = re.match( r'(.*) REDHAT', line, re.M|re.I)

if matchObj:
   print ("matchObj.group() : ", matchObj.group())
   print ("matchObj.groups() : ", matchObj.groups())
   #print ("matchObj.group(0) : ", matchObj.group(0))
else:
   print ("No match!!")
'''
ARE == ARE
ARE == Are
ARE == aRe
ARE == arE
ARE == are'''
