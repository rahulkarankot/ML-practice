#!/usr/bin/python3

import re

line = "Python and Perl are programming languages"

#searchObj = re.search( r'(.*)are (.*)(.*?)', line, re.M|re.I)

searchObj = re.search(r'are', line, re.M|re.I)

"""
5.  .		Any Character [.	matches any character]
15. *	        Zero or more repetitions
17. ?	        Optional character [?	0 or 1 (append ? for non-greedy)]
23. (.*)	Capture all
"""

if searchObj:
   print ("searchObj.group() : ", searchObj.group())
   #print ("searchObj.group(1) : ", searchObj.group(1))
   #print ("searchObj.group(2) : ", searchObj.groups())
else:
   print ("Nothing found!!")
